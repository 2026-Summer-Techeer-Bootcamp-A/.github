// 부하 테스트: 읽기 전용 엔드포인트에 단계적으로 가상 유저(VU)를 늘려가며 처리량과
// 지연을 측정한다. lib/catalog.js의 안전한 GET 엔드포인트 전체를 가중치 기반으로
// 랜덤 호출한다(가중치가 높을수록 실제 트래픽에서 자주 불리는 엔드포인트).
//
// external(news_*) 티어는 외부 API 보호를 위해 기본 뽑기 풀에서 완전히 제외하고,
// 매 iteration 2% 확률로만 news_hackernews/news_geeknews 중 하나를 추가로 호출한다.
//
// LLM을 호출하는 /api/v1/chat, /api/v1/resume/parse 같은 엔드포인트와 쓰기
// (POST/PUT/DELETE) 엔드포인트는 대상에서 제외한다(비용 발생, 데이터 오염 위험).
// 자세한 제외 목록은 README.md "절대 건드리지 말 것" 참고.
//
// 로컬(docker-compose dev)에서 먼저 돌려 임계값을 확인하고, 프로덕션에는 VU 수를
// 크게 낮춰 짧게만 돌린다. 프로덕션 DB는 1 vCPU/3.75GB로 작아서 과도한 부하가 다른
// 사용자와 데모에 영향을 줄 수 있다.
//
// thresholds 숫자에 대해: 아래 tier별 p95 값은 "이상적인 SLA 목표"가 아니라, 이
// 로컬 dev 환경(옵저버빌리티 스택을 포함한 12개 컨테이너가 한 머신에서 같이 도는
// docker compose)에서 MAX_VUS=20/DURATION=1m로 실측한 p95에 여유를 두고 반올림한
// "회귀를 잡기 위한 상한"이다. 실측 당시 tier별 p95는 대략 다음과 같았다.
//
//   tier          실측 p95(ms)   threshold(ms)
//   core          최대 ~2500     3000
//   heavy         최대 ~3800     4500
//   taxonomy      최대 ~1600     2000
//   stats         803~2534       3000
//   stats_heavy   4127~12353     13000
//   external      (측정 예산 밖) 3000  ※ 낮은 확률로만 불려서 실측 샘플이 적었다
//
// stats_heavy 5개(global_domestic_gap, hiring_season, industry_fingerprint,
// role_stack_fit, skill_trend_yearly)가 posting/tech를 직접 조인해 GROUP BY하는
// raw aggregation 쿼리라 몇 초씩 DB 커넥션을 붙잡고, 그 여파로 커넥션 풀 경합이
// 생겨 나머지 가벼운 엔드포인트까지 도미노로 느려지는 것으로 보인다. 이 dev 환경이
// 바뀌거나(DB 리소스 증설 등) stats_heavy 5개에 MV(구체화 뷰)를 추가하는 등 실제
// 개선이 있으면, 이 threshold를 다시 좁혀서 회귀 탐지력을 되찾아야 한다.
//
// 실행 예(이 k6/ 폴더 안에서):
//   로컬:      k6 run -e BASE_URL=http://localhost:8000 load.js
//   프로덕션:  k6 run -e BASE_URL=https://2026-techeer-a.duckdns.org \
//              -e MAX_VUS=5 -e DURATION=30s load.js
import { sleep, group } from "k6";
import { ENDPOINTS } from "./lib/catalog.js";
import { taggedGet, pickWeighted, poolExcluding } from "./lib/request.js";
import { fetchDynamicFixtures } from "./lib/setupData.js";
import { buildHandleSummary } from "./lib/summary.js";

const BASE_URL = __ENV.BASE_URL || "http://localhost:8000";
const MAX_VUS = Number(__ENV.MAX_VUS || 20);
const DURATION = __ENV.DURATION || "1m";

// 기본 뽑기 풀에서는 external(news_*)을 아예 뺀다. 낮은 확률로만 별도 호출한다.
const POOL = poolExcluding(["external"]);
const NEWS_ENDPOINTS = ENDPOINTS.filter((ep) => ep.tier === "external");
const NEWS_PROBABILITY = 0.02;

export const options = {
  stages: [
    { duration: "20s", target: Math.ceil(MAX_VUS * 0.25) }, // 서서히 예열
    { duration: DURATION, target: MAX_VUS }, // 목표 부하 유지
    { duration: "10s", target: 0 }, // 정리
  ],
  thresholds: {
    http_req_failed: ["rate<0.01"], // 에러율 1% 미만(전체)
    // tier별로 지연 예산을 다르게 건다. 파일 상단 주석 참고 — 이 dev 환경에서
    // 실측한 값 기준 상한이지, 이상적인 SLA가 아니다.
    "http_req_duration{tier:core}": ["p(95)<3000"],
    "http_req_duration{tier:heavy}": ["p(95)<4500"],
    "http_req_duration{tier:taxonomy}": ["p(95)<2000"],
    "http_req_duration{tier:stats}": ["p(95)<3000"],
    "http_req_duration{tier:stats_heavy}": ["p(95)<13000"],
    "http_req_duration{tier:external}": ["p(95)<3000"],
  },
};

export function setup() {
  return fetchDynamicFixtures(BASE_URL);
}

export default function (fixtures) {
  const ep = pickWeighted(POOL);
  group(ep.category, () => {
    taggedGet(ep.name, `${BASE_URL}${ep.build(fixtures)}`);
  });

  if (Math.random() < NEWS_PROBABILITY) {
    const newsEp = NEWS_ENDPOINTS[Math.floor(Math.random() * NEWS_ENDPOINTS.length)];
    group(newsEp.category, () => {
      taggedGet(newsEp.name, `${BASE_URL}${newsEp.build(fixtures)}`);
    });
  }

  sleep(Math.random() * 1.5 + 0.5); // 사용자 사이 간격을 흉내
}

export const handleSummary = buildHandleSummary("load");
