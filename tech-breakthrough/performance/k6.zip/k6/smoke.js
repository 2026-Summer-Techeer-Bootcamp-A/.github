// 스모크 테스트: lib/catalog.js에 등록된 안전한 GET 엔드포인트 전부를 1 VU로
// 순서대로 딱 한 번씩 호출한다. 랜덤 선택이 아니라 카탈로그 배열을 그대로
// 순회해서, 목표는 커버리지 100%다(어떤 엔드포인트든 응답 스키마가 깨지거나
// 500이 나면 여기서 먼저 걸린다).
//
// 부하테스트(load/stress/breakpoint/spike) 전에 항상 먼저 돌려서 스크립트 자체와
// 대상 서버의 기본 동작을 검증한다.
//
// 실행(이 k6/ 폴더 안에서): k6 run -e BASE_URL=http://localhost:8000 smoke.js
import { sleep, group } from "k6";
import { ENDPOINTS } from "./lib/catalog.js";
import { taggedGet } from "./lib/request.js";
import { fetchDynamicFixtures } from "./lib/setupData.js";
import { buildHandleSummary } from "./lib/summary.js";

const BASE_URL = __ENV.BASE_URL || "http://localhost:8000";

export const options = {
  vus: 1,
  iterations: 1, // 한 번의 iteration 안에서 카탈로그 전체를 순회하므로 1회면 충분
  thresholds: {
    http_req_failed: ["rate==0"],
  },
};

export function setup() {
  return fetchDynamicFixtures(BASE_URL);
}

export default function (fixtures) {
  for (const ep of ENDPOINTS) {
    group(ep.category, () => {
      taggedGet(ep.name, `${BASE_URL}${ep.build(fixtures)}`);
    });
    sleep(0.2); // 카탈로그가 30개 가까이 되니 짧게만 쉰다
  }
}

export const handleSummary = buildHandleSummary("smoke");
